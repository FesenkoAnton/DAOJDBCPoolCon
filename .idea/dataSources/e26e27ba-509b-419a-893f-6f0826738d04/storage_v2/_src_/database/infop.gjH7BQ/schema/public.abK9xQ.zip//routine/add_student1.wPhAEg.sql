create function add_student1(nam character varying)
  returns void
language plpgsql
as $$
BEGIN
update students set name=nam where id=13;
  END;
$$;

alter function add_student1(varchar)
  owner to postgres;

