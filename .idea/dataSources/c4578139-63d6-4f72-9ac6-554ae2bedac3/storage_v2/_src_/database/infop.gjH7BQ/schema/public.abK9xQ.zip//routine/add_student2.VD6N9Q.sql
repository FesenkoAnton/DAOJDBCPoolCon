create function add_student2()
  returns void
language plpgsql
as $$
BEGIN
CREATE TABLE IF NOT EXISTS lll_lll (
  user_id integer PRIMARY KEY ,
  username varchar(45) NOT NULL,
  password varchar(450) NOT NULL,
  enabled integer NOT NULL DEFAULT '1'
);
 END;
$$;

alter function add_student2()
  owner to postgres;

