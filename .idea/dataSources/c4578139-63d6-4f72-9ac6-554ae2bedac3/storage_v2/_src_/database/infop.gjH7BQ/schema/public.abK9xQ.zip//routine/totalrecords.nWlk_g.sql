create function totalrecords()
  returns integer
language plpgsql
as $$
declare
  total integer;
BEGIN
  SELECT count(*) into total FROM students;
  RETURN total;
END;
$$;

alter function totalrecords()
  owner to postgres;

