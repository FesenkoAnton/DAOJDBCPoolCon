create function "getName"()
  returns void
language sql
as $fun$
CREATE OR REPLACE FUNCTION getName() RETURNS void AS $$
BEGIN
update students set name='Olya' where id=13;
END;
$$
LANGUAGE 'plpgsql';
$fun$;

alter function "getName"()
  owner to postgres;

