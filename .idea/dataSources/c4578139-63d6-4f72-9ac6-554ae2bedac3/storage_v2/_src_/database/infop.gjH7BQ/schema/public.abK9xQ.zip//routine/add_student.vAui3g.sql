create function add_student()
  returns void
language sql
as $fun$
CREATE OR REPLACE FUNCTION add_student( nam VARCHAR ) 
    RETURNS void AS $$
    BEGIN
      update students set name=nam where id=13;
    END;
    $$ LANGUAGE plpgsql;
$fun$;

alter function add_student()
  owner to postgres;

